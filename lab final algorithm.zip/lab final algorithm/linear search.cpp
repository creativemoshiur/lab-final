#include<iostream>

using namespace std;

int linear_search(int a[] , int len, int item)
{
    for(int i = 0;i < len;i++)
    {
        if(a[i] == item)
        {
            return i;
        }
    }
    return -1;
}
void display(int a[], int len)
{
    for(int i = 0; i < len; i++)
        cout << a[i] << "\t";
}
int main()
{
    int a[5] = {21,15,10,30,8};
    cout << "Element  : " << endl;
    display(a, 5);
    int item;
    cout << "\nEnter your search item : ";
    cin >> item;
    int result = linear_search(a, 5,item);

    if(result == -1)
    {
        cout << item << " is not found" << endl;
    }
    else
    {
        cout << item << " is found at index " << result << endl;
    }
    return 0;
}
