#include<iostream>
#include<fstream>
#include<sstream>

using namespace std;

int main()
{
    string value;
    string arr[3000];
    int a[3000];
    ifstream file("input.txt");
    int cnt = 0;
    ofstream opp;
    opp.open("output.txt");
    while(getline(file , value))
    {
        arr[cnt] = value;
        cnt++;
    }
    for(int i = 0; i < cnt;i++)
    {
        stringstream file1(arr[i]);
        int x = 0;
        file1 >>  x;
        a[i] = x;
    }
    for(int j = 0; j < cnt;j++)
    {
        opp << a[j] << endl;
    }


    file.close();

    return 0;
}
