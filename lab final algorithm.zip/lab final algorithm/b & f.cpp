#include<bits/stdc++.h>
#include<iostream>
#include<fstream>
#include<sstream>
#include<time.h>

using namespace std;

void bubble_sort(int a[], int len)
{
    for(int i = 0; i < len - 1; i++)
    {
        for(int j = 0; j < len - 1 - i; j++)
        {
            if(a[j] > a[j+ 1])
            {
                swap(a[j], a[j+1]);
            }
        }
    }
}

int main()
{
    string value;
    string arr[3000];
    int a[3000];
    ifstream file("input.txt");
    int cnt = 0;
    ofstream opp;
    opp.open("output.txt");
    while(getline(file , value))
    {
        arr[cnt] = value;
        cnt++;
    }
    for(int i = 0; i < cnt;i++)
    {
        stringstream file1(arr[i]);
        int x = 0;
        file1 >>  x;
        a[i] = x;
    }
    clock_t time_req;
    time_req = clock();
   bubble_sort(a, cnt);
   time_req = clock() - time_req;// 3 - 1

    opp << "Time duration : " <<  (float)time_req/CLOCKS_PER_SEC  << " second."<< endl;

   for(int i = 0; i < cnt; i++)
        opp << a[i] << endl;

    file.close();

    return 0;
}

