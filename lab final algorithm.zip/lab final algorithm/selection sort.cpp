#include<bits/stdc++.h>

using namespace std;

void swap(int *a,int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
void selection_sort(int a[], int len)
{
    int min_index;
    for(int i = 0; i < len - 1; i++)
    {
        min_index = i;

        for(int j = i + 1; j < len; j++)
        {
            if(a[j] < a[min_index])
            {
                min_index = j;
            }

        }
        if(min_index != i)
        {
            swap(&a[min_index], &a[i]);
        }
    }

}
void display(int a[], int len)
{
    for(int i = 0; i < len; i++)
        cout << a[i] << "\t";
}
int main()
{
    int a[5] = {21,15,10,30,8};
    cout << "Before sorting : " << endl;
    display(a, 5);
    selection_sort(a, 5);
    cout << "\nAfter sorting : " << endl;
    display(a, 5);


    return 0;
}
