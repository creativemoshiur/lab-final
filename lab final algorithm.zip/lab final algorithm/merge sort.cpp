#include<bits/stdc++.h>
using namespace std;

void merge_sort(int a[] , int s , int m , int e)
{
    int len1 = m - s + 1;
    int len2 = e - m;

    int left[len1] , right[len2];

    for(int i = 0;i < len1;i++)
    {
        left[i] = a[s + i];
    }
    for(int j = 0;j < len2;j++)
    {
        right[j] = a[m + 1 + j];
    }

    int i = 0;
    int j = 0;
    int k = s;

    while(i < len1 && j < len2)
    {
        if(left[i] < right[j])
        {
            a[k] = left[i];
            i++;
        }
        else
        {
            a[k] = right[j];
            j++;
        }
        k++;
    }
    while(i < len1)
    {
          a[k] = left[i];
          i++;
          k++;
    }
    while(j < len2)
    {
        a[k] = right[j];
        j++;
        k++;
    }
}
void merge_sort(int a[] , int s ,int e)
{
    if(s < e)
    {
        int mid = (s+e)/2;
        merge_sort(a , s ,mid);
        merge_sort(a , mid + 1 , e);
        merge_sort(a , s , mid , e);
    }
}
void display(int a[], int len)
{
    for(int i = 0; i < len; i++)
        cout << a[i] << "\t";
}
int main()
{
    int a[5] = {21,15,10,30,8};
    cout << "Before sorting : " << endl;
    display(a, 5);
    merge_sort(a, 0 , 5 - 1);
    cout << "\nAfter sorting : " << endl;
    display(a, 5);


    return 0;
}
