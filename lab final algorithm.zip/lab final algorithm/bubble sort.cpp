#include<bits/stdc++.h>

using namespace std;

void bubble_sort(int a[], int len)
{
    for(int i = 0; i < len - 1; i++)
    {
        for(int j = 0; j < len - 1 - i; j++)
        {
            if(a[j] > a[j+ 1])
            {
                swap(a[j], a[j+1]);
            }
        }
    }
}
void display(int a[], int len)
{
    for(int i = 0; i < len; i++)
        cout << a[i] << "\t";
}
int main()
{
    int a[5] = {21,15,10,30,8};
    cout << "Before sorting : " << endl;
    display(a, 5);
    bubble_sort(a, 5);
    cout << "\nAfter sorting : " << endl;
    display(a, 5);


    return 0;
}
