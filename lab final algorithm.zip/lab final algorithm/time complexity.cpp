#include<iostream>
#include<time.h>

using namespace std;

int main()
{
    clock_t time_req;
    time_req = clock();// 1
    for(int i = 0;i < 4000;i++)
    {
        cout << i << endl;
    }
    time_req = clock() - time_req;// 3 - 1

    cout << "Time duration : " <<  (float)time_req/CLOCKS_PER_SEC  << " second."<< endl;

    return 0;
}
