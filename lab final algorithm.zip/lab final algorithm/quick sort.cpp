#include<bits/stdc++.h>

using namespace std;

void swap(int *a , int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
int partition(int a[] , int low , int high)
{
    int pivot = a[high];

    int i = (low - 1);

    for(int j = low; j < high - 1;j++)
    {
        if(a[j] < pivot)
        {
            i++;
            swap(&a[i] ,&a[j]);
        }
    }
    swap(&a[i + 1] , &a[high]);
    return i + 1;
}
void quick_sort(int a[] , int low ,int high)
{
    if(low < high)
    {
        int p = partition(a , low , high);
        quick_sort(a , low , p - 1);
        quick_sort(a , p + 1 , high);
    }
}
void display(int a[], int len)
{
    for(int i = 0; i < len; i++)
        cout << a[i] << "\t";
}
int main()
{
    int a[5] = {21,15,10,30,8};
    cout << "Before sorting : " << endl;
    display(a, 5);
    quick_sort(a, 0,5-1);
    cout << "\nAfter sorting : " << endl;
    display(a, 5);


    return 0;
}

