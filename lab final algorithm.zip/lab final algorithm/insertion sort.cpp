#include<bits/stdc++.h>
using namespace std;

void insertion_sort(int a[],int len)
{
    for(int i = 1;i <len;i++)
    {
        int temp = a[i];
        int j = i - 1;

        while(j >= 0 && a[j] > temp)
        {
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = temp;
    }
}
void display(int a[], int len)
{
    for(int i = 0; i < len; i++)
        cout << a[i] << "\t";
}
int main()
{
     int a[5] = {21,15,10,30,8};
    cout << "Before sorting : " << endl;
    display(a, 5);
    insertion_sort(a, 5);
    cout << "\nAfter sorting : " << endl;
    display(a, 5);

    return 0;
}
